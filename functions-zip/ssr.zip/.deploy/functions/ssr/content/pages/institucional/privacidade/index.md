---
title: Política de Privacidade
meta_title: Política de Privacidade
meta_description: Política de Privacidade
group: institucional
---
### Política de Privacidade

Nos comprometemos a preservar os dados de todos os clientes, informações importantes como senha e CPF são criptografadas no momento do cadastro, antes de serem salvas. A finalização da sua compra será realizada em ambiente seguro e nenhuma informação relacionada a cartões de crédito ou contas bancárias será armazenada em nossos bancos de dados. Os dados cadastrais dos clientes não são vendidos, trocados ou divulgados para terceiros, exceto quando essas informações são necessárias para o processo de entrega, para cobrança, ou para participação em promoções solicitadas pelos clientes. Seus dados pessoais são peça fundamental para que seu pedido chegue em segurança, na sua casa, de acordo com nosso prazo de entrega. Nosso site utiliza cookies e informações de sua navegação (sessão do browser) com o objetivo de traçar um perfil do público que visita o site e aperfeiçoar sempre nossos serviços, produtos, conteúdos e garantir as melhores ofertas e promoções para você. Estas informações são registradas automaticamente e serão mantidas em sigilo absoluto. Qualquer alteração sobre nossa política de privacidade será devidamente informada nesta página
